// This file intentionally left blank
// This file is required to make the Arduino IDE recognize the folder as a library and thus display the examples under the File > Examples > Larduino_HSP Examples menu after a Larduino_HSP board is selected
